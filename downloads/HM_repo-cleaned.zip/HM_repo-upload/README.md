# Vitals: crew health monitor

A JavaFX desktop app for the NASA Space Apps challenge "Health Monitoring Software". Crew members log their vitals;
the app compares each reading with that person's own normal, shows it on a 3D body, and says what to do about it.

## Run it

You need JDK 21 or newer. Maven is included (the `mvnw` wrapper); the first run downloads the libraries.

```bash
./mvnw javafx:run
```

On Windows use `mvnw.cmd javafx:run`. To start with one simulated crew member already in the database:

```bash
./mvnw javafx:run "-Djavafx.args=--demo"
```

Run the unit tests with `./mvnw test`, and the built-in end-to-end check of the real window with:

```bash
./mvnw javafx:run "-Djavafx.args=--smoke"
```

The check uses a throw-away database and a stand-in for the microphone and OpenAI. It prints `PASS` and writes
screenshots of every screen to `target/smoke/`.

## The pages

| Page | What it is for |
| --- | --- |
| **Status** | The twelve metric panels on a wheel, and for the one in the middle: its trend, what it means and what to do |
| **Body** | A 3D figure. Each body system takes the colour of its status and gets a marker over the area; the list beside it shows the readings behind it. "Open" jumps to that metric on Status |
| **Log vitals** | One form for everything measured at one sitting. Saving writes one row to the database |
| **How to use** | A card per piece of equipment, each opening its step-by-step guide |

The bar under the tabs holds the launch date, the mission day being viewed, the hazard focus, the mission
environment and the calendar language (English or Brazilian Portuguese). The calendar no longer follows the
computer's own language. Only the calendar and date format are translated; the rest of the app is in English.

## Urine colour

Hydration is recorded as one of seven colour groups: clear to pale yellow, dark yellow, orange, brown, pink to red,
green, cloudy or milky. Each group has its own level and its own advice (in `catalog.json`). A database made by an
earlier version, which used an eight-step shade scale, is converted the first time this version opens it.

## Voice

Voice does one thing: it calls up a panel on the Status page. Press **Voice**, say a panel name, and it comes up;
the recording stops by itself after four seconds. Nothing spoken can save, change or delete anything, so there is
never anything to confirm.

| Say | Panel |
| --- | --- |
| heart rate, pulse | Heart rate |
| blood pressure, upper pressure, systolic | Pressure, upper |
| lower pressure, diastolic | Pressure, lower |
| blood sugar, glucose | Blood sugar |
| temperature | Temperature |
| blood oxygen, oxygen | Blood oxygen |
| sleep | Sleep |
| mood | Mood |
| urine colour, urine, hydration | Urine colour |
| exercise, workout | Exercise |
| body mass, weight | Body mass |
| grip strength, strength | Grip strength |

Speech is turned into text by OpenAI, so voice needs your own API key with billing enabled: press **Key** and paste
it, or set `OPENAI_API_KEY` before starting the app. The key stays in memory and is never written to disk. Only the
short recording is sent; which panel was meant is worked out on this computer (`voice/VoiceCommand.java`).

## The database

Everything the app shows comes from one SQLite file, `HealthMonitor.db`, created in the folder you start the app from.
It is not committed to git. Delete the file to start empty, or pass `--db=path/to/file.db` in `javafx.args`.

| Table | What it holds |
| --- | --- |
| `astronaut` | Name, optional height, and launch date (mission day 0) |
| `data` | One row per log entry: who, when, which mission day, and a column per vital. Only what was measured is filled in |
| `settings` | Small app-wide choices, such as the calendar language |

The tables are defined in `src/main/resources/com/example/healthmonitor/schema.sql`. It runs at every start and only
creates what is missing; it never deletes anything.

## Where things are

| Path | What it holds |
| --- | --- |
| `.../healthmonitor/MainApp.java` | The window: tabs, crew, mission bar, and which page is showing |
| `.../healthmonitor/Database.java`, `schema.sql` | Opening the database, creating its tables, converting older ones |
| `.../healthmonitor/Astronaut*.java`, `Measurement*.java` | Crew members and log entries, and reading and writing them |
| `.../healthmonitor/DatabaseReadingStore.java` | The link between the pages and the `data` table |
| `.../healthmonitor/body/` | The 3D figure (`BodyView`) and the Body page |
| `.../healthmonitor/pages/` | The Log vitals and How to use pages |
| `.../healthmonitor/voice/` | Microphone capture, speech-to-text, and the list of voice commands |
| `.../healthmonitor/AppSmoke.java`, `DemoData.java` | The end-to-end check, and the simulated crew member (every value invented) |
| `src/main/java/org/hm/health/` | The Status page: wheel, detail card, chart, equipment guides, and the assessment rules |
| `src/main/resources/health/` | The stylesheet for the whole app, fonts, the catalogue (limits, advice, guides) and the demo readings |
| `src/main/resources/body/` | The 3D body model |
| `3D-Model/chromium-body-viewer/` | The earlier browser-based viewer. No longer used: the Body page draws the same model natively |

To change a limit, a piece of advice, a colour group or a guide, edit `src/main/resources/health/catalog.json`.
Every colour, radius and font is in `src/main/resources/health/health.css`.

## Limits

- The limits, advice and equipment guides are reference text written for a prototype. They need review by a flight
  surgeon before anyone relies on them. The app supports a crew member's judgement; it does not diagnose.
- There is no sign-in: anyone who can open the app can read and change the data.
- The 3D figure needs a graphics card JavaFX supports. Where it does not, the Body page shows the list without the figure.

## Credits

- Look: after the Plush widgets (plush-ui, MIT) and the Apple Health summary; no Plush code or Apple assets are included.
- Font: Open Runde, SIL Open Font Licence. See `licenses/`.
- 3D body models: BodyParts3D, © The Database Center for Life Science, CC Attribution-Share Alike 2.1 Japan
  (simplified and merged; they remain under that licence).
