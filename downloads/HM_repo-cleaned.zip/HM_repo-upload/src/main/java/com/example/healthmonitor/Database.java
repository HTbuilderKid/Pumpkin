package com.example.healthmonitor;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
    private static String dbUrl = "jdbc:sqlite:HealthMonitor.db";

    public static void setDbUrl(String url){
        dbUrl = url;
    }

    public static Connection getConnection() throws SQLException {
        Connection con = DriverManager.getConnection(dbUrl);
        try(Statement stm = con.createStatement()){
            stm.execute("PRAGMA foreign_keys = ON;");
        }
        return con;
    }

    public static void init() throws SQLException {
        String schema;
        try (var in = Database.class.getResourceAsStream("schema.sql")) {
            if (in == null) throw new SQLException("schema.sql is missing from the application");
            schema = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new SQLException("schema.sql could not be read", e);
        }
        String statements = schema.replaceAll("(?m)--.*$", "");
        try (Connection con = getConnection(); Statement stm = con.createStatement()) {
            boolean hadData;
            try (var rs = stm.executeQuery("SELECT count(*) FROM sqlite_master WHERE type = 'table' AND name = 'data'")) { hadData = rs.next() && rs.getInt(1) > 0; }
            for (String sql : statements.split(";")) if (!sql.isBlank()) stm.execute(sql);
            int version;
            try (var rs = stm.executeQuery("PRAGMA user_version")) { version = rs.next() ? rs.getInt(1) : 0; }
            if (version < 1) {
                // Version 1: urine colour changed from an eight-step shade scale to seven colour groups.
                // A database made before that still holds the old numbers: move them to the matching group.
                if (hadData) stm.execute("UPDATE data SET urine_color = CASE WHEN urine_color <= 3 THEN 1 WHEN urine_color <= 5 THEN 2 WHEN urine_color = 6 THEN 3 ELSE 4 END WHERE urine_color IS NOT NULL");
                stm.execute("PRAGMA user_version = 1");
            }
        }
    }

    public static String setting(String key, String fallback) {
        try (Connection con = getConnection(); var ps = con.prepareStatement("SELECT value FROM settings WHERE key = ?")) {
            ps.setString(1, key);
            try (var rs = ps.executeQuery()) { return rs.next() ? rs.getString(1) : fallback; }
        } catch (SQLException e) { return fallback; }
    }

    public static void saveSetting(String key, String value) {
        try (Connection con = getConnection(); var ps = con.prepareStatement("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value")) {
            ps.setString(1, key); ps.setString(2, value); ps.executeUpdate();
        } catch (SQLException e) { /* a choice that cannot be saved is simply not remembered */ }
    }
}
