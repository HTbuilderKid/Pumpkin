package com.example.healthmonitor;

import com.example.healthmonitor.body.BodyPage;
import com.example.healthmonitor.pages.GuidesPage;
import com.example.healthmonitor.pages.LogVitalsPage;
import com.example.healthmonitor.voice.VoiceControlPanel;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.hm.health.HealthCatalog;
import org.hm.health.HealthSession;
import org.hm.health.HealthStatusPane;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainApp extends Application {
    static final Map<String, Locale> LANGUAGES = new LinkedHashMap<>();
    static { LANGUAGES.put("English", Locale.US); LANGUAGES.put("Português (Brasil)", Locale.forLanguageTag("pt-BR")); }

    final AstronautDAO astronauts = new AstronautDAO();
    final ComboBox<Astronaut> crew = new ComboBox<>();
    final ComboBox<String> language = new ComboBox<>();
    final Spinner<Integer> day = new Spinner<>(0, 0, 0);
    final ToggleGroup tabs = new ToggleGroup();
    final StackPane pages = new StackPane(), statusSlot = new StackPane(), launchSlot = new StackPane();
    final ComboBox<HealthCatalog.Hazard> hazard = new ComboBox<>();
    final ComboBox<HealthCatalog.Environment> environment = new ComboBox<>();
    final Label today = new Label();
    private final BorderPane root = new BorderPane();
    private final HBox missionBar = new HBox(10);
    HealthCatalog catalog;
    HealthStatusPane page;
    BodyPage bodyPage;
    LogVitalsPage logPage;
    GuidesPage guidesPage;
    VoiceControlPanel voice;
    DatePicker launch;
    Stage stage;
    private Region empty;
    private boolean updating;          // true while the controls are being filled in by the program, not the user

    @Override
    public void start(Stage stage) throws Exception {
        this.stage = stage;
        boolean smoke = getParameters().getUnnamed().contains("--smoke");
        String db = getParameters().getNamed().get("db");
        if (smoke) db = java.nio.file.Files.createTempDirectory("vitals-smoke-").resolve("smoke.db").toString();
        if (db != null) Database.setDbUrl("jdbc:sqlite:" + db);
        Database.init();
        String saved = Database.setting("language", "English");
        Locale.setDefault(LANGUAGES.getOrDefault(saved, Locale.US));
        catalog = HealthCatalog.load();
        HealthStatusPane.loadFonts();
        if ((getParameters().getUnnamed().contains("--demo") || smoke) && astronauts.findAll().isEmpty()) DemoData.load();

        bodyPage = new BodyPage(catalog); logPage = new LogVitalsPage(catalog); guidesPage = new GuidesPage(catalog);
        bodyPage.setOnOpenMetric(this::openMetric);
        pages.getChildren().addAll(statusSlot, bodyPage, logPage, guidesPage);

        Label brand = new Label("Vitals"); brand.getStyleClass().add("brand");
        HBox tabBar = new HBox(4, tab("Status", "status"), tab("Body", "body"), tab("Log vitals", "log"), tab("How to use", "guides")); tabBar.getStyleClass().add("tabs");
        tabs.selectedToggleProperty().addListener((o, was, now) -> { if (now == null) tabs.selectToggle(was); else showPage(); });
        voice = smoke ? new VoiceControlPanel(this::voiceShow, (wav, key) -> "show sleep", () -> () -> java.util.concurrent.CompletableFuture.completedFuture(new byte[64])) : new VoiceControlPanel(this::voiceShow);
        Button add = new Button("Add crew"); add.setId("crew-add"); add.setOnAction(e -> addCrew());
        crew.setId("crew"); crew.setPrefWidth(220); crew.setPromptText("No crew yet");
        crew.setOnAction(e -> { if (!updating) show(crew.getValue()); });
        Region gap = new Region(); HBox.setHgrow(gap, Priority.ALWAYS);
        HBox top = new HBox(14, brand, tabBar, gap, voice, crew, add); top.setAlignment(Pos.CENTER_LEFT); top.getStyleClass().add("health-toolbar");

        day.setId("view-day"); day.setPrefWidth(96);
        day.valueProperty().addListener((o, a, b) -> { if (!updating && page != null && b != null) { page.setMissionDay(b); bodyPage.show(page.session(), b); } });
        hazard.getItems().addAll(catalog.hazards()); hazard.setPromptText("No hazard focus"); hazard.setPrefWidth(200);
        hazard.setOnAction(e -> { if (page != null) page.setHazard(hazard.getValue() == null ? null : hazard.getValue().id()); });
        Button clear = new Button("Clear"); clear.getStyleClass().add("mini"); clear.setOnAction(e -> hazard.setValue(null));
        environment.getItems().addAll(catalog.environments()); environment.setValue(catalog.environments().get(0)); environment.setPrefWidth(230);
        environment.setOnAction(e -> { if (page != null) page.setEnvironment(environment.getValue().id()); });
        language.setId("language"); language.getItems().addAll(LANGUAGES.keySet()); language.setValue(LANGUAGES.containsKey(saved) ? saved : "English"); language.setPrefWidth(190);
        language.setOnAction(e -> setLanguage(language.getValue()));
        Button remove = new Button("Remove crew member"); remove.setId("crew-remove"); remove.getStyleClass().add("mini"); remove.setOnAction(e -> removeCrew());
        Region gap2 = new Region(); HBox.setHgrow(gap2, Priority.ALWAYS);
        missionBar.getChildren().addAll(new Label("Launched"), launchSlot, today, divider(), new Label("Viewing day"), day, divider(), hazard, clear, environment, gap2, new Label("Calendar"), language, remove);
        missionBar.setAlignment(Pos.CENTER_LEFT); missionBar.getStyleClass().addAll("health-toolbar", "mission-bar");
        newLaunchPicker();
        for (HBox bar : List.of(top, missionBar)) for (Node node : bar.getChildren()) if (node instanceof Label || node instanceof Button) ((Region) node).setMinWidth(Region.USE_PREF_SIZE);

        VBox bars = new VBox(top, missionBar); bars.getStylesheets().add(css());
        root.setTop(bars); root.setCenter(pages);
        Scene scene = new Scene(root, 1600, 1000);
        stage.setTitle("Vitals · Health monitor"); stage.setScene(scene); stage.setMinWidth(1240); stage.setMinHeight(700);
        tabs.selectToggle(tabs.getToggles().get(0));
        refreshCrew(null);
        stage.show();
        if (smoke) new AppSmoke(this).run();
    }

    private static String css() { return HealthStatusPane.class.getResource("/health/health.css").toExternalForm(); }
    private static Region divider() { Region line = new Region(); line.getStyleClass().add("divider"); return line; }
    private ToggleButton tab(String text, String id) { ToggleButton b = new ToggleButton(text); b.setId("tab-" + id); b.setUserData(id); b.setToggleGroup(tabs); b.getStyleClass().add("tab"); b.setMinWidth(Region.USE_PREF_SIZE); return b; }
    String currentPage() { return tabs.getSelectedToggle() == null ? "status" : (String) tabs.getSelectedToggle().getUserData(); }
    void go(String pageId) { tabs.getToggles().stream().filter(t -> pageId.equals(t.getUserData())).findFirst().ifPresent(tabs::selectToggle); }

    private void showPage() {
        String id = currentPage(); boolean none = crew.getValue() == null;
        Map<String, Node> all = Map.of("status", statusSlot, "body", bodyPage, "log", logPage, "guides", guidesPage);
        all.forEach((key, node) -> { boolean on = key.equals(id) && !(none && !key.equals("status")); node.setVisible(on); node.setManaged(on); });
        if (none) { statusSlot.setVisible(true); statusSlot.setManaged(true); }
        missionBar.setVisible(!none); missionBar.setManaged(!none);
    }

    /** A new date picker for the launch date. Made afresh whenever the calendar language changes, because a picker keeps the language it was born with. */
    private void newLaunchPicker() {
        launch = new DatePicker(crew.getValue() == null ? null : crew.getValue().getLaunchDate());
        launch.setId("launch"); launch.setPrefWidth(150); launch.setEditable(false);
        launch.setOnAction(e -> { if (!updating) changeLaunch(); });
        launchSlot.getChildren().setAll(launch);
    }

    void setLanguage(String name) {
        Locale locale = LANGUAGES.get(name); if (locale == null) return;
        Locale.setDefault(locale); Database.saveSetting("language", name);
        updating = true; newLaunchPicker(); updating = false;
    }

    void refreshCrew(Astronaut select) throws Exception {
        List<Astronaut> all = astronauts.findAll();
        updating = true;
        crew.getItems().setAll(all);
        Astronaut chosen = select == null ? null : all.stream().filter(a -> a.getId() == select.getId()).findFirst().orElse(null);
        if (chosen == null && !all.isEmpty()) chosen = all.get(0);
        crew.setValue(chosen);
        updating = false;
        show(chosen);
    }

    private void show(Astronaut astronaut) {
        if (page != null) { page.close(); page = null; }
        if (astronaut == null) {
            if (empty == null) empty = emptyState();
            statusSlot.getChildren().setAll(empty); bodyPage.show(null, 0); logPage.bind("", null, null); guidesPage.bind(null); showPage(); return;
        }
        try {
            int now = astronaut.missionDay(LocalDate.now());
            HealthSession session = new HealthSession(catalog, new DatabaseReadingStore(astronaut.getId()), Integer.toString(astronaut.getId()), now);
            page = new HealthStatusPane(session);
            int first = session.readings().stream().mapToInt(r -> r.day()).min().orElse(now);
            String dayText = now > 0 ? "mission day " + now : now == 0 ? "launch day" : -now + " days before launch";
            updating = true;
            launch.setValue(astronaut.getLaunchDate());
            day.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(Math.min(first, now), now, now));
            today.setText(dayText);
            updating = false;
            page.setEnvironment(environment.getValue().id());
            if (hazard.getValue() != null) page.setHazard(hazard.getValue().id());
            session.assess(now).entrySet().stream().max(java.util.Comparator.comparingInt(e -> e.getValue().level())).ifPresent(e -> page.setSelectedIndicator(e.getKey()));
            statusSlot.getChildren().setAll(page);
            final HealthStatusPane current = page;
            bodyPage.select(catalog.indicator(page.selectedIndicator()).system());
            page.setOnSystemLevels(levels -> bodyPage.show(session, current.missionDay()));
            page.setOnSystemSelected(bodyPage::select);
            guidesPage.bind(page);
            logPage.bind(astronaut.getName() + " · " + dayText, (values, saved, failed) -> current.saveToday(values).whenComplete((v, f) -> {
                if (f == null) saved.run(); else { Throwable cause = f; while (cause.getCause() != null) cause = cause.getCause(); failed.accept(cause.getMessage()); }
            }), page);
        } catch (Exception e) {
            updating = false;
            statusSlot.getChildren().setAll(message("The data for " + astronaut.getName() + " could not be loaded.", e.getMessage()));
        }
        showPage();
    }

    void openMetric(String indicatorId) { if (page == null) return; go("status"); page.setSelectedIndicator(indicatorId); }
    private String voiceShow(String indicatorId) {
        if (page == null) return "Add a crew member first.";
        openMetric(indicatorId);
        return "Showing " + catalog.indicator(indicatorId).shortName().toLowerCase(Locale.ROOT);
    }

    private void changeLaunch() {
        Astronaut astronaut = crew.getValue();
        if (astronaut == null || launch.getValue() == null) return;
        try { astronauts.setLaunchDate(astronaut.getId(), launch.getValue()); astronaut.setLaunchDate(launch.getValue()); show(astronaut); }
        catch (Exception e) { error("The launch date could not be saved.", e); }
    }

    void addCrew() {
        Dialog<ButtonType> dialog = new Dialog<>(); dialog.initOwner(stage); dialog.setTitle("Add crew"); dialog.setHeaderText("Add a crew member");
        sheet(dialog.getDialogPane());
        TextField name = new TextField(); name.setId("crew-name"); name.setPromptText("Name"); name.setPrefWidth(380);
        DatePicker launched = new DatePicker(LocalDate.now()); launched.setId("crew-launch"); launched.setEditable(false); launched.setMaxWidth(Double.MAX_VALUE);
        Label problem = new Label(); problem.getStyleClass().add("error-text"); problem.setWrapText(true);
        Label note = new Label("The launch date is mission day 0. Readings logged before it become this person's baseline: their own normal that later readings are compared with.");
        note.getStyleClass().add("muted"); note.setWrapText(true); note.setMaxWidth(380);
        VBox box = new VBox(8, caption("Name"), name, caption("Launch date"), launched, note, problem); box.getStyleClass().add("sheet-body");
        dialog.getDialogPane().setContent(box);
        ButtonType addType = new ButtonType("Add", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CANCEL, addType);
        Button addButton = (Button) dialog.getDialogPane().lookupButton(addType); addButton.getStyleClass().add("primary"); addButton.setId("crew-save");
        addButton.addEventFilter(javafx.event.ActionEvent.ACTION, e -> {
            String text = name.getText() == null ? "" : name.getText().trim();
            if (text.isEmpty()) { problem.setText("Enter a name first."); e.consume(); }
            else if (text.length() > 60) { problem.setText("That name is too long (60 characters at most)."); e.consume(); }
            else try { refreshCrew(astronauts.addAstronaut(text, launched.getValue())); } catch (Exception ex) { problem.setText("Could not save: " + ex.getMessage()); e.consume(); }
        });
        javafx.application.Platform.runLater(name::requestFocus);
        dialog.showAndWait();
    }
    private static Label caption(String text) { Label l = new Label(text); l.getStyleClass().add("caption"); return l; }
    private static void sheet(DialogPane pane) { pane.getStylesheets().add(css()); pane.getStyleClass().addAll("health-guide", "sheet"); }

    private void removeCrew() {
        Astronaut astronaut = crew.getValue();
        if (astronaut == null) return;
        Alert ask = new Alert(Alert.AlertType.NONE, "Everything " + astronaut.getName() + " has logged is deleted with them. This cannot be undone.", ButtonType.CANCEL, new ButtonType("Remove", ButtonBar.ButtonData.OK_DONE));
        ask.initOwner(stage); ask.setTitle("Remove crew member"); ask.setHeaderText("Remove " + astronaut.getName() + "?"); sheet(ask.getDialogPane());
        if (ask.showAndWait().map(b -> b.getButtonData() != ButtonBar.ButtonData.OK_DONE).orElse(true)) return;
        try { astronauts.deleteAstronaut(astronaut.getId()); refreshCrew(null); }
        catch (Exception e) { error("The crew member could not be removed.", e); }
    }

    private Region emptyState() {
        Button add = new Button("Add a crew member"); add.getStyleClass().add("primary"); add.setOnAction(e -> addCrew());
        Button demo = new Button("Load a simulated crew member"); demo.setId("load-demo");
        demo.setOnAction(e -> { try { refreshCrew(DemoData.load()); } catch (Exception ex) { error("The demo data could not be loaded.", ex); } });
        HBox buttons = new HBox(10, add, demo); buttons.setAlignment(Pos.CENTER);
        VBox box = (VBox) message("Health monitoring for the final frontier", "Add a crew member to start logging, or load a simulated one to see how the app works. The simulated readings are invented.");
        box.getChildren().add(buttons);
        return box;
    }

    private Region message(String heading, String text) {
        Label h = new Label(heading); h.getStyleClass().add("page-title");
        Label t = new Label(text); t.getStyleClass().add("muted"); t.setWrapText(true); t.setMaxWidth(520); t.setAlignment(Pos.CENTER); t.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        VBox box = new VBox(14, h, t); box.setAlignment(Pos.CENTER); box.getStyleClass().add("health-page");
        box.getStylesheets().add(css());
        return box;
    }

    private void error(String what, Exception e) {
        Alert alert = new Alert(Alert.AlertType.NONE, e.getMessage() == null ? e.toString() : e.getMessage(), ButtonType.OK);
        alert.initOwner(stage); alert.setTitle("Vitals"); alert.setHeaderText(what); sheet(alert.getDialogPane()); alert.showAndWait();
    }

    @Override
    public void stop() { if (voice != null) voice.close(); if (page != null) page.close(); }

    public static void main(String[] args) { launch(args); }
}
