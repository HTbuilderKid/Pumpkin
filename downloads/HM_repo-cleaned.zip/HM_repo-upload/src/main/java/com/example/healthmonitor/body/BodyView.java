package com.example.healthmonitor.body;

import com.google.gson.Gson;
import javafx.animation.AnimationTimer;
import javafx.application.ConditionalFeature;
import javafx.application.Platform;
import javafx.geometry.Point2D;
import javafx.geometry.Point3D;
import javafx.scene.AmbientLight;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.PointLight;
import javafx.scene.SceneAntialiasing;
import javafx.scene.SubScene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Circle;
import javafx.scene.shape.CullFace;
import javafx.scene.shape.MeshView;
import javafx.scene.shape.TriangleMesh;
import javafx.scene.transform.Rotate;
import org.hm.health.HealthCatalog;
import org.hm.health.HealthStatusPane;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/** Models: BodyParts3D, (c) The Database Center for Life Science, CC Attribution-Share Alike 2.1 Japan (simplified). */
public final class BodyView extends Region {
    private record MeshInfo(String name, int nv, int ni, int offV, int offI, double[] min, double[] size, double[] centre) {}
    private record Meta(String units, double height, List<MeshInfo> meshes, Map<String, double[]> spots) {}
    private record Part(MeshView view, PhongMaterial material, String system, boolean bone, boolean skin) {}

    private static final List<String> SKELETON = List.of("skull", "spine", "ribcage", "pelvis", "arms", "legs");
    private static final Color SKIN = see(Color.web("#6f8db5"), .10), BONE = Color.web("#ebe4d3"), CAGE = see(Color.web("#ebe4d3"), .4), ORGAN = Color.web("#dbe2ec"), CHOSEN = Color.web("#141414");

    /** A see-through colour. JavaFX 3D adds a see-through surface's colour on top of what is behind it, so the colour is dimmed by its own opacity first. */
    private static Color see(Color c, double opacity) { return new Color(c.getRed() * opacity, c.getGreen() * opacity, c.getBlue() * opacity, opacity); }

    private final Map<String, Part> parts = new LinkedHashMap<>();
    private final Map<String, Point3D> spots = new HashMap<>();
    private final Map<String, Label> markers = new LinkedHashMap<>();
    private final Map<String, Integer> levels = new HashMap<>();
    private static final List<String> CAGES = List.of("skull", "ribcage");      // bones that enclose organs are drawn see-through
    private final Group figure = new Group(), shape = new Group(), inside = new Group();
    private final Rotate turn = new Rotate(0, Rotate.Y_AXIS);
    private final PerspectiveCamera camera = new PerspectiveCamera(true);
    private final Pane overlay = new Pane();
    private SubScene scene3d;
    private String selected;
    private Consumer<String> onPick = id -> {};
    private boolean hover, dragging, available;
    private double dragX, moved, distance = 440, goalDistance = 440, lift, goalLift;
    private final AnimationTimer spin = new AnimationTimer() {
        private long last;
        @Override public void handle(long now) {
            double dt = last == 0 ? 0 : Math.min(.05, (now - last) / 1e9); last = now;
            if (!hover && !dragging) turn.setAngle(turn.getAngle() + dt * 16);
            distance += (goalDistance - distance) * Math.min(1, dt * 5); lift += (goalLift - lift) * Math.min(1, dt * 5);
            camera.setTranslateZ(-distance); camera.setTranslateY(lift);
            placeMarkers();
        }
    };

    public BodyView(HealthCatalog catalog) {
        getStyleClass().add("body-view"); setMinSize(0, 0);
        available = Platform.isSupported(ConditionalFeature.SCENE3D);
        if (!available) {
            Label sorry = new Label("This computer's graphics cannot draw the 3D body. The list beside it shows the same information.");
            sorry.getStyleClass().add("muted"); sorry.setWrapText(true); sorry.setMaxWidth(320); getChildren().add(sorry); return;
        }
        Meta meta; ByteBuffer bytes;
        try (var json = BodyView.class.getResourceAsStream("/body/body.json"); var bin = BodyView.class.getResourceAsStream("/body/body.bin")) {
            if (json == null || bin == null) throw new IOException("The body model is missing from the application");
            meta = new Gson().fromJson(new String(json.readAllBytes(), StandardCharsets.UTF_8), Meta.class);
            bytes = ByteBuffer.wrap(bin.readAllBytes()).order(ByteOrder.LITTLE_ENDIAN);
        } catch (IOException e) { throw new IllegalStateException(e); }

        Map<String, String> systemOfMesh = new HashMap<>();
        for (var s : catalog.systems()) if (s.meshes() != null) for (String m : s.meshes()) systemOfMesh.put(m, s.id());
        Map<String, double[]> centres = new HashMap<>();
        // organs and solid bones first, then the see-through bones, which blend over what is already drawn
        for (int pass = 0; pass < 2; pass++) for (MeshInfo m : meta.meshes()) {
            boolean skin = m.name().equals("skin"), bone = SKELETON.contains(m.name());
            if ((pass == 1) != CAGES.contains(m.name())) continue;
            TriangleMesh mesh = new TriangleMesh();
            float[] points = new float[m.nv() * 3];
            for (int i = 0; i < points.length; i++) {
                double v = m.min()[i % 3] + (bytes.getShort(m.offV() + 2 * i) & 0xffff) / 65535.0 * m.size()[i % 3];
                points[i] = (float) (i % 3 == 0 ? v : -v);                // model: y up, front +z.  JavaFX: y down, camera on the -z side
            }
            int[] faces = new int[m.ni() * 2];
            // each triangle's corners are read in reverse order: JavaFX decides which side is the outside the other way round from the model
            for (int i = 0; i < m.ni(); i++) faces[2 * (i - i % 3 + 2 - i % 3)] = bytes.getShort(m.offI() + 2 * i) & 0xffff;
            mesh.getPoints().setAll(points); mesh.getTexCoords().setAll(0, 0); mesh.getFaces().setAll(faces);
            MeshView view = new MeshView(mesh);
            PhongMaterial material = new PhongMaterial(); material.setSpecularColor(Color.web("#202020")); material.setSpecularPower(20);
            view.setMaterial(material); view.setCullFace(skin ? CullFace.NONE : CullFace.BACK);
            String system = systemOfMesh.get(m.name());
            if (skin) view.setMouseTransparent(true);
            else view.setOnMouseClicked(e -> { if (moved < 5) onPick.accept(system != null ? system : bone ? "bone" : null); });
            parts.put(m.name(), new Part(view, material, skin ? null : system, bone, skin));
            centres.put(m.name(), m.centre());
            (skin ? shape : inside).getChildren().add(view);
        }
        figure.getChildren().addAll(inside, shape);     // the skin is a faint haze drawn last, over everything inside it
        for (var s : catalog.systems()) {
            double[] at = centres.containsKey(s.spot()) ? centres.get(s.spot()) : meta.spots() == null ? null : meta.spots().get(s.spot());
            if (at != null) spots.put(s.id(), new Point3D(at[0], -at[1], -at[2]));
            Label marker = new Label(s.shortName()); marker.getStyleClass().add("body-marker"); marker.setManaged(false); marker.setVisible(false);
            marker.setGraphic(new Circle(5)); marker.setGraphicTextGap(7); marker.setOnMouseClicked(e -> onPick.accept(s.id()));
            markers.put(s.id(), marker); overlay.getChildren().add(marker);
        }
        figure.getTransforms().add(turn);
        PointLight key = new PointLight(Color.web("#787878"));       // Ambient plus key light must stay below full white to avoid washing out colours.
        AmbientLight flat = new AmbientLight(Color.WHITE), soft = new AmbientLight(Color.web("#808080"));
        flat.getScope().add(shape); soft.getScope().add(inside); key.getScope().add(inside);
        Group world = new Group(figure, flat, soft, key);
        camera.setFieldOfView(26); camera.setNearClip(1); camera.setFarClip(4000); camera.setTranslateZ(-distance);
        scene3d = new SubScene(world, 100, 100, true, SceneAntialiasing.BALANCED);
        scene3d.setFill(Color.TRANSPARENT); scene3d.setCamera(camera);
        overlay.setPickOnBounds(false);
        getChildren().addAll(scene3d, overlay);

        setOnMouseEntered(e -> hover = true); setOnMouseExited(e -> hover = false);
        setOnMousePressed(e -> { dragX = e.getSceneX(); moved = 0; dragging = true; });
        setOnMouseDragged(e -> { double dx = e.getSceneX() - dragX; dragX = e.getSceneX(); moved += Math.abs(dx); turn.setAngle(turn.getAngle() - dx * .6); });
        setOnMouseReleased(e -> dragging = false);
        setOnScroll(e -> { goalDistance = Math.max(170, Math.min(520, goalDistance - e.getDeltaY() * .9)); e.consume(); });
        sceneProperty().addListener((o, was, now) -> { if (now != null) spin.start(); else spin.stop(); });
        paint();
    }

    public boolean available() { return available; }
    public void setOnPick(Consumer<String> listener) { onPick = listener; }

    public void setLevels(Map<String, Integer> next) { levels.clear(); levels.putAll(next); paint(); }

    /** Emphasise one body system and move in on it; null shows the whole figure. */
    public void select(String systemId) {
        selected = systemId;
        Point3D at = systemId == null ? null : spots.get(systemId);
        boolean wide = at == null || List.of("bone", "muscle", "core").contains(systemId);
        goalDistance = wide ? 440 : 330; goalLift = at == null ? 0 : at.getY() * (wide ? .25 : .75);
        paint();
    }

    private void paint() {
        if (!available) return;
        for (Part p : parts.values()) {
            if (p.skin()) { p.material().setDiffuseColor(SKIN); continue; }
            int level = p.system() == null ? 0 : levels.getOrDefault(p.system(), 0);
            boolean chosen = p.system() != null && p.system().equals(selected);
            boolean cage = CAGES.contains(name(p));
            Color solid = level > 0 ? Color.web(HealthStatusPane.levelColor(level)) : chosen ? Color.web("#5d6f8c") : null;
            Color c = solid == null ? (cage ? CAGE : p.bone() ? BONE : ORGAN) : cage ? see(solid, .55) : solid;
            p.material().setDiffuseColor(c);
        }
        for (var e : markers.entrySet()) {
            int level = levels.getOrDefault(e.getKey(), 0); boolean chosen = e.getKey().equals(selected); Label m = e.getValue();
            m.setVisible(spots.containsKey(e.getKey()) && (level > 0 || chosen));
            ((Circle) m.getGraphic()).setFill(level > 0 ? Color.web(HealthStatusPane.levelColor(level)) : CHOSEN);
            m.pseudoClassStateChanged(javafx.css.PseudoClass.getPseudoClass("selected"), chosen);
        }
    }

    private String name(Part part) { return parts.entrySet().stream().filter(e -> e.getValue() == part).map(Map.Entry::getKey).findFirst().orElse(""); }

    private void placeMarkers() {
        for (var e : markers.entrySet()) {
            Label m = e.getValue(); if (!m.isVisible()) continue;
            Point3D at = spots.get(e.getKey());
            Point2D onScreen = overlay.sceneToLocal(toScene(figure.localToScene(at, true)));
            double w = m.prefWidth(-1), h = m.prefHeight(-1);
            boolean flip = onScreen.getX() > getWidth() * .62;
            m.resizeRelocate(flip ? onScreen.getX() - w + 12 : onScreen.getX() - 12, onScreen.getY() - h / 2, w, h);
            m.setNodeOrientation(flip ? javafx.geometry.NodeOrientation.RIGHT_TO_LEFT : javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        }
    }
    private static Point2D toScene(Point3D p) { return new Point2D(p.getX(), p.getY()); }

    @Override protected void layoutChildren() {
        double w = getWidth(), h = getHeight();
        if (!available) { getChildren().get(0).resizeRelocate(Math.max(0, (w - 320) / 2), Math.max(0, h / 2 - 40), Math.min(w, 320), 80); return; }
        scene3d.setWidth(Math.max(1, w)); scene3d.setHeight(Math.max(1, h));
        overlay.resizeRelocate(0, 0, w, h);
    }
    @Override protected double computePrefWidth(double height) { return 520; }
    @Override protected double computePrefHeight(double width) { return 640; }
}
