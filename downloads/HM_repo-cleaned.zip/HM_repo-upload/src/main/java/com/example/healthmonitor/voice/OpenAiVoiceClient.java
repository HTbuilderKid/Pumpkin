package com.example.healthmonitor.voice;

import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;

public final class OpenAiVoiceClient implements VoiceAi {
    private static final Gson JSON=new Gson();
    private final HttpClient http;
    private final URI base;
    public OpenAiVoiceClient(){this(HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build(),URI.create("https://api.openai.com/v1/"));}
    OpenAiVoiceClient(HttpClient http,URI base){this.http=http;this.base=base;}
    @Override public String transcribe(byte[] wav,String key)throws Exception{
        if(wav.length<45||wav.length>6_000_000)throw new IllegalArgumentException("Say one short panel name.");
        String boundary="voice-"+UUID.randomUUID();
        byte[] prefix=("--"+boundary+"\r\nContent-Disposition: form-data; name=\"model\"\r\n\r\ngpt-4o-mini-transcribe\r\n--"+boundary+"\r\nContent-Disposition: form-data; name=\"language\"\r\n\r\nen\r\n--"+boundary+"\r\nContent-Disposition: form-data; name=\"prompt\"\r\n\r\nThe speaker names one health panel: "+String.join(", ",VoiceCommand.examples())+".\r\n--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\"command.wav\"\r\nContent-Type: audio/wav\r\n\r\n").getBytes(StandardCharsets.UTF_8);
        byte[] suffix=("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8);
        var body=HttpRequest.BodyPublishers.concat(HttpRequest.BodyPublishers.ofByteArray(prefix),HttpRequest.BodyPublishers.ofByteArray(wav),HttpRequest.BodyPublishers.ofByteArray(suffix));
        JsonObject response=send("audio/transcriptions","multipart/form-data; boundary="+boundary,body,key);
        String text=response.get("text").getAsString().strip();if(text.isEmpty())throw new IllegalArgumentException("No speech was recognized. Please try again.");return text;
    }
    private JsonObject send(String path,String contentType,HttpRequest.BodyPublisher body,String key)throws Exception{
        if(key==null||key.isBlank())throw new IllegalArgumentException("Set your OpenAI API key first.");
        if(key.strip().chars().anyMatch(c->c<33||c>126))throw new IllegalArgumentException("API key contains invalid characters. Paste the key alone, without quotes or spaces.");
        var request=HttpRequest.newBuilder(base.resolve(path)).timeout(Duration.ofSeconds(90)).header("Authorization","Bearer "+key.strip()).header("Content-Type",contentType).POST(body).build();
        var response=http.send(request,HttpResponse.BodyHandlers.ofString());
        if(response.statusCode()/100!=2)throw new java.io.IOException(switch(response.statusCode()){
            case 401->"OpenAI rejected the API key. Check it in Voice settings.";
            case 403->"This API key/project does not have access to the requested model.";
            case 429->"OpenAI quota or rate limit reached. Check API billing/limits and try later.";
            default->"OpenAI request failed (HTTP "+response.statusCode()+"). Check connectivity and model access.";
        });
        try{return JsonParser.parseString(response.body()).getAsJsonObject();}catch(RuntimeException e){throw new java.io.IOException("OpenAI returned an unreadable response.");}
    }
}
