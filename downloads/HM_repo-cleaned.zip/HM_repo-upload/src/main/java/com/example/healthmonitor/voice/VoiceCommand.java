package com.example.healthmonitor.voice;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Matches panel names locally; voice commands never modify stored data. */
public record VoiceCommand(Action action, String indicator, String message) {
    public enum Action { SHOW_METRIC, HELP, UNSUPPORTED }

    /** Every Status panel and the phrases that call it up. Longer phrases win, so "lower blood pressure" beats "blood pressure". */
    static final Map<String, List<String>> PHRASES = new LinkedHashMap<>();
    static {
        PHRASES.put("hr", List.of("heart rate", "heartrate", "pulse", "heart"));
        PHRASES.put("bp_sys", List.of("upper blood pressure", "upper pressure", "pressure upper", "systolic pressure", "systolic", "blood pressure", "pressure"));
        PHRASES.put("bp_dia", List.of("lower blood pressure", "lower pressure", "pressure lower", "diastolic pressure", "diastolic"));
        PHRASES.put("glucose", List.of("blood sugar", "blood glucose", "glucose", "sugar"));
        PHRASES.put("temp", List.of("body temperature", "temperature", "temp"));
        PHRASES.put("spo2", List.of("blood oxygen", "oxygen saturation", "oxygen", "saturation"));
        PHRASES.put("sleep", List.of("sleep"));
        PHRASES.put("mood", List.of("mood"));
        PHRASES.put("hydration", List.of("urine colour", "urine color", "urine", "hydration"));
        PHRASES.put("exercise", List.of("exercise", "workout", "training"));
        PHRASES.put("mass", List.of("body mass", "body weight", "weight", "mass"));
        PHRASES.put("strength", List.of("grip strength", "strength", "grip"));
    }

    public static List<String> examples() { return PHRASES.values().stream().map(p -> p.get(0)).toList(); }
    public static String help() { return "Say a panel name: " + String.join(", ", examples()) + "."; }

    private static String longest(String said) {
        String best = null; int length = 0;
        for (var panel : PHRASES.entrySet()) for (String phrase : panel.getValue())
            if (phrase.length() > length && said.contains(" " + phrase + " ")) { best = panel.getKey(); length = phrase.length(); }
        return best;
    }

    public static VoiceCommand match(String heard) {
        String said = " " + (heard == null ? "" : heard).toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9]+", " ").strip() + " ";
        if (said.isBlank()) return new VoiceCommand(Action.UNSUPPORTED, null, "Nothing was heard. " + help());
        String best = longest(said), phrase = best == null ? null : PHRASES.get(best).stream().filter(p -> said.contains(" " + p + " ")).max(java.util.Comparator.comparingInt(String::length)).orElseThrow();
        // one panel at a time: once the matched phrase is taken out, no other panel may still be named
        boolean tie = best != null && longest(said.replace(" " + phrase + " ", " ")) != null;
        if (best != null && !tie) return new VoiceCommand(Action.SHOW_METRIC, best, null);
        if (said.contains(" help ") || said.contains(" what can i say ")) return new VoiceCommand(Action.HELP, null, help());
        return new VoiceCommand(Action.UNSUPPORTED, null, (tie ? "That matched more than one panel. " : "No panel matched “" + heard.strip() + "”. ") + help());
    }
}
