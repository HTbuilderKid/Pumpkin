package com.example.healthmonitor.pages;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import org.hm.health.HealthCatalog;
import org.hm.health.HealthStatusPane;

import java.util.stream.Collectors;

public final class GuidesPage extends ScrollPane {
    private HealthStatusPane guides;

    public GuidesPage(HealthCatalog catalog) {
        getStyleClass().add("health-page"); getStylesheets().add(HealthStatusPane.class.getResource("/health/health.css").toExternalForm());
        setFitToWidth(true); setHbarPolicy(ScrollBarPolicy.NEVER);
        Label title = new Label("How to use"); title.getStyleClass().add("page-title");
        Label lead = new Label("Pick a piece of equipment for a step-by-step guide, with timers where a step means waiting."); lead.getStyleClass().add("muted");
        FlowPane cards = new FlowPane(16, 16); cards.setPrefWrapLength(2400);
        for (var e : catalog.equipment()) {
            Label name = new Label(e.name()); name.getStyleClass().add("action-title"); name.setWrapText(true);
            Label measures = new Label("Measures " + e.measures().stream().map(id -> catalog.indicator(id).shortName().toLowerCase()).collect(Collectors.joining(", "))); measures.getStyleClass().add("caption"); measures.setWrapText(true);
            Label what = new Label(e.what()); what.getStyleClass().add("body-text"); what.setWrapText(true);
            Region gap = new Region(); VBox.setVgrow(gap, Priority.ALWAYS);
            Button open = new Button("Open guide  →"); open.setId("guide-" + e.id()); open.getStyleClass().add("primary"); open.setOnAction(a -> { if (guides != null) guides.openGuide(e.id()); });
            VBox card = new VBox(10, name, measures, what, gap, open); card.getStyleClass().add("panel"); card.setPrefWidth(350); card.setMinHeight(250);
            cards.getChildren().add(card);
        }
        Label note = new Label(catalog.equipmentNote()); note.getStyleClass().add("muted"); note.setWrapText(true);
        VBox head = new VBox(2, title, lead); head.setPadding(new Insets(0, 5, 0, 5));
        VBox root = new VBox(18, head, cards, note); root.setPadding(new Insets(22, 24, 28, 24));
        setContent(root);
    }

    public void bind(HealthStatusPane guides) { this.guides = guides; }
}
