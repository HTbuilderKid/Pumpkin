package com.example.healthmonitor.voice;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import org.hm.health.HealthStatusPane;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** OpenAI transcribes speech; panel matching is local and the API key stays in memory. */
public final class VoiceControlPanel extends HBox implements AutoCloseable {
    public interface Host { String show(String indicatorId); }

    private static final Duration LISTEN = Duration.seconds(4);
    private final VoiceAi ai; private final AudioCapture audio; private final Host host;
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> { var t = new Thread(r, "voice-api"); t.setDaemon(true); return t; });
    private final Button talk = new Button("Voice"), settings = new Button("Key");
    private final Label status = new Label();
    private final PauseTransition limit = new PauseTransition(LISTEN);
    private volatile String key = System.getenv("OPENAI_API_KEY");
    private AudioCapture.Recording recording;
    private boolean busy, closed;

    public VoiceControlPanel(Host host) { this(host, new OpenAiVoiceClient(), new MicrophoneCapture()); }
    public VoiceControlPanel(Host host, VoiceAi ai, AudioCapture audio) {
        this.host = host; this.ai = ai; this.audio = audio;
        setSpacing(8); setAlignment(Pos.CENTER_LEFT); getStyleClass().add("voice");
        talk.setId("voice-talk"); settings.setId("voice-key"); status.setId("voice-status");
        talk.setMinWidth(Region.USE_PREF_SIZE); settings.setMinWidth(Region.USE_PREF_SIZE); settings.getStyleClass().add("mini");
        talk.setTooltip(new Tooltip(VoiceCommand.help())); settings.setTooltip(new Tooltip("Your OpenAI API key, for speech recognition. It is kept in memory only."));
        status.getStyleClass().add("voice-status"); status.setMaxWidth(250); status.setMinWidth(0);
        getChildren().addAll(talk, settings, status);
        settings.setOnAction(e -> configure());
        talk.setOnAction(e -> { if (recording != null) stopRecording(); else startRecording(); });
        limit.setOnFinished(e -> { if (recording != null) stopRecording(); });
        say(hasKey() ? "Say a panel name" : "Add a key to use voice");
        update();
    }

    public void handle(String heard) {
        VoiceCommand command = VoiceCommand.match(heard);
        say(command.action() == VoiceCommand.Action.SHOW_METRIC ? host.show(command.indicator()) : command.message());
    }
    public String statusText() { return status.getText(); }
    public void useKey(String value) { key = value == null ? null : value.strip(); update(); }

    private void configure() {
        Dialog<String> dialog = new Dialog<>(); dialog.initOwner(getScene().getWindow()); dialog.setTitle("Voice"); dialog.setHeaderText("OpenAI API key");
        dialog.getDialogPane().getStylesheets().add(HealthStatusPane.class.getResource("/health/health.css").toExternalForm()); dialog.getDialogPane().getStyleClass().addAll("health-guide", "sheet");
        PasswordField secret = new PasswordField(); secret.setId("voice-key-input"); secret.setPromptText("Paste your API key"); secret.setPrefWidth(430);
        Label note = new Label((hasKey() ? "A key is already in use. " : "") + "Voice sends a short recording to OpenAI to turn speech into text, so it needs your own API key with billing enabled. "
                + "The key stays in memory until the app closes and is never written to disk. You can also set OPENAI_API_KEY before starting the app.");
        note.setWrapText(true); note.getStyleClass().add("body-text"); note.setMaxWidth(430);
        VBox box = new VBox(14, note, secret); box.getStyleClass().add("sheet-body"); dialog.getDialogPane().setContent(box);
        ButtonType use = new ButtonType("Use key", ButtonBar.ButtonData.OK_DONE); dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CANCEL, use);
        dialog.getDialogPane().lookupButton(use).getStyleClass().add("primary");
        dialog.setResultConverter(b -> b == use ? secret.getText() : null);
        dialog.showAndWait().ifPresent(value -> { if (!value.isBlank()) { key = value.strip(); say("Say a panel name"); } update(); });
        secret.clear();
    }

    private boolean hasKey() { return key != null && !key.isBlank(); }
    private void say(String text) { status.setText(text); status.setTooltip(text == null || text.length() < 34 ? null : new Tooltip(text)); }
    private void update() {
        talk.setDisable(busy || !hasKey()); settings.setDisable(busy || recording != null);
        talk.setText(recording == null ? "Voice" : "Stop");
        talk.getStyleClass().remove("recording"); if (recording != null) talk.getStyleClass().add("recording");
    }

    private void startRecording() {
        if (!hasKey() || busy) return;
        busy = true; say("Opening microphone…"); update();
        CompletableFuture.supplyAsync(() -> { try { return audio.start(); } catch (Exception e) { throw new CompletionException(e); } }, worker).whenComplete((r, f) -> Platform.runLater(() -> {
            busy = false;
            if (closed) { if (r != null) r.close(); return; }
            if (f != null) { failure(f); return; }
            recording = r; say("Listening… say a panel name"); limit.playFromStart(); update();
        }));
    }

    private void stopRecording() {
        limit.stop(); var capture = recording; recording = null; busy = true; update(); say("Recognising…"); String activeKey = key;
        capture.stop().thenApplyAsync(wav -> { try { return ai.transcribe(wav, activeKey); } catch (Exception e) { throw new CompletionException(e); } }, worker)
            .whenComplete((text, error) -> Platform.runLater(() -> {
                if (closed) return;
                busy = false;
                if (error != null) failure(error); else { handle(text); update(); }
            }));
    }

    private void failure(Throwable error) {
        busy = false; Throwable cause = error; while (cause.getCause() != null) cause = cause.getCause();
        String message = cause instanceof java.net.http.HttpTimeoutException ? "OpenAI took too long. Try again." : cause instanceof java.net.ConnectException ? "Could not reach OpenAI. Check the connection." : cause.getMessage();
        say(message == null ? "Voice did not work. Try again." : message); update();
    }

    @Override public void close() { closed = true; limit.stop(); if (recording != null) recording.close(); key = null; worker.shutdownNow(); }
}
