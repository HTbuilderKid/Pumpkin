package com.example.healthmonitor.body;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import org.hm.health.AssessmentEngine;
import org.hm.health.HealthCatalog;
import org.hm.health.HealthSession;
import org.hm.health.HealthStatusPane;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public final class BodyPage extends HBox {
    private final HealthCatalog catalog;
    private final BodyView body;
    private final VBox systems = new VBox(8), detail = new VBox(12);
    private final Label summary = new Label();
    private HealthSession session;
    private int day;
    private String selected;
    private Consumer<String> onOpenMetric = id -> {};

    public BodyPage(HealthCatalog catalog) {
        this.catalog = catalog;
        getStyleClass().add("health-page"); getStylesheets().add(HealthStatusPane.class.getResource("/health/health.css").toExternalForm());
        setSpacing(22); setPadding(new Insets(22, 24, 28, 24));
        body = new BodyView(catalog); body.setOnPick(this::select);
        Label title = new Label("Body"); title.getStyleClass().add("page-title");
        Label hint = new Label(body.available() ? "Drag to turn · scroll to zoom · click a part" : ""); hint.getStyleClass().add("muted");
        Region gap = new Region(); HBox.setHgrow(gap, Priority.ALWAYS);
        HBox head = new HBox(12, title, gap, hint); head.setAlignment(Pos.BOTTOM_LEFT);
        StackPane stage = new StackPane(body); stage.getStyleClass().add("panel"); stage.setPadding(new Insets(8)); VBox.setVgrow(stage, Priority.ALWAYS);
        VBox left = new VBox(14, head, stage); HBox.setHgrow(left, Priority.ALWAYS); left.setMinWidth(0);

        summary.getStyleClass().add("muted"); summary.setWrapText(true);
        Label listTitle = new Label("Body systems"); listTitle.getStyleClass().add("detail-title");
        detail.getStyleClass().add("action-card");
        VBox side = new VBox(14, listTitle, summary, systems, detail); side.getStyleClass().add("panel");
        ScrollPane scroll = new ScrollPane(side); scroll.setFitToWidth(true); scroll.getStyleClass().add("plain-scroll"); scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setPrefWidth(470); scroll.setMinWidth(380); scroll.setMaxWidth(520);
        getChildren().addAll(left, scroll);
    }

    public void setOnOpenMetric(Consumer<String> listener) { onOpenMetric = listener; }

    public void show(HealthSession session, int day) { this.session = session; this.day = day; refresh(); }
    public void select(String systemId) { selected = systemId != null && catalog.systems().stream().anyMatch(s -> s.id().equals(systemId)) ? systemId : null; body.select(selected); refresh(); }
    public String selectedSystem() { return selected; }
    public BodyView view() { return body; }

    private void refresh() {
        systems.getChildren().clear(); detail.getChildren().clear();
        if (session == null) { summary.setText("No crew member selected."); detail.setVisible(false); detail.setManaged(false); return; }
        Map<String, Integer> levels = session.systemLevels(day); var results = session.assess(day);
        body.setLevels(levels);
        long flagged = levels.values().stream().filter(l -> l > 0).count();
        summary.setText(results.values().stream().allMatch(r -> r.value() == null) ? "No readings yet. Log vitals to see the body respond."
                : flagged == 0 ? "Every system is in its normal range." : flagged + (flagged == 1 ? " system needs" : " systems need") + " attention. They are coloured and marked on the figure.");
        for (var s : catalog.systems()) {
            int level = levels.getOrDefault(s.id(), 0);
            boolean measured = catalog.daily().stream().anyMatch(i -> i.system().equals(s.id()) && results.get(i.id()).value() != null);
            Label name = new Label(s.name()); name.getStyleClass().add("row-title"); name.setMinWidth(0); HBox.setHgrow(name, Priority.ALWAYS); name.setMaxWidth(Double.MAX_VALUE);
            Label state = new Label(!measured ? "No readings" : catalog.levels().get(level).name()); state.getStyleClass().add("row-state");
            if (measured) state.setStyle("-fx-text-fill:" + HealthStatusPane.levelTextColor(level) + ";");
            Button row = new Button(); row.getStyleClass().add("list-row"); if (s.id().equals(selected)) row.getStyleClass().add("selected");
            HBox content = new HBox(10, new Circle(5.5, measured ? Color.web(HealthStatusPane.levelColor(level)) : Color.web("#c9c9c6")), name, state, chevron());
            content.setAlignment(Pos.CENTER_LEFT); row.setGraphic(content); row.setMaxWidth(Double.MAX_VALUE); content.prefWidthProperty().bind(row.widthProperty().subtract(32));
            row.setId("system-" + s.id()); row.setOnAction(e -> select(s.id().equals(selected) ? null : s.id()));
            systems.getChildren().add(row);
        }
        var chosen = catalog.systems().stream().filter(s -> s.id().equals(selected)).findFirst().orElse(null);
        detail.setVisible(chosen != null); detail.setManaged(chosen != null);
        if (chosen == null) return;
        Label heading = new Label(chosen.name()); heading.getStyleClass().add("action-title"); heading.setWrapText(true);
        Label about = new Label(chosen.about()); about.getStyleClass().add("body-text"); about.setWrapText(true);
        detail.getChildren().addAll(heading, about);
        List<HealthCatalog.Indicator> inSystem = catalog.daily().stream().filter(i -> i.system().equals(chosen.id())).toList();
        if (inSystem.isEmpty()) { Label none = new Label("No daily measurement covers this system yet."); none.getStyleClass().add("muted"); none.setWrapText(true); detail.getChildren().add(none); }
        for (var ind : inSystem) {
            var r = results.get(ind.id()); boolean empty = r.value() == null;
            Label name = new Label(ind.shortName()); name.getStyleClass().add("row-title");
            Label value = new Label(empty ? "No reading yet" : AssessmentEngine.format(ind, r.value()) + (ind.unit().isEmpty() ? "" : " " + ind.unit())); value.getStyleClass().add("muted");
            Label note = new Label(empty ? "" : (r.remeasure() ? "Re-measure first" : catalog.levels().get(r.level()).name()) + " · " + AssessmentEngine.describe(ind, r)); note.getStyleClass().add("caption"); note.setWrapText(true);
            if (!empty) note.setStyle("-fx-text-fill:" + HealthStatusPane.levelTextColor(r.level()) + ";");
            VBox text = new VBox(2, name, value, note); HBox.setHgrow(text, Priority.ALWAYS); text.setMinWidth(0);
            Button open = new Button("Open  →"); open.setId("open-" + ind.id()); open.setMinWidth(Region.USE_PREF_SIZE); open.setOnAction(e -> onOpenMetric.accept(ind.id()));
            HBox line = new HBox(10, new Circle(5.5, empty ? Color.web("#c9c9c6") : Color.web(HealthStatusPane.levelColor(r.level()))), text, open); line.setAlignment(Pos.CENTER_LEFT); line.getStyleClass().add("metric-line");
            detail.getChildren().add(line);
        }
    }
    private static Node chevron() { Label c = new Label("›"); c.getStyleClass().add("chevron"); return c; }
}
