package com.example.healthmonitor.voice;

public interface VoiceAi {
    String transcribe(byte[] wav, String key) throws Exception;
}
