package com.example.healthmonitor;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.stage.Window;
import javafx.util.Duration;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;

/** Offline end-to-end check (--smoke); microphone and OpenAI calls are simulated. */
final class AppSmoke {
    private final MainApp app;
    AppSmoke(MainApp app) { this.app = app; }

    void run() {
        delay(1800).thenRun(() -> {
            check(app.crew.getValue() != null && app.crew.getValue().getName().equals(DemoData.NAME), "The simulated crew member is loaded from the database");
            check(app.page.lookupAll(".metric-tile").size() == 12, "12 panels on the Status wheel");
            snap(app.stage.getScene().getRoot(), "1-status.png");
            for (var ind : app.catalog.daily()) {
                app.voice.handle("show " + ind.shortName());
                check(app.page.selectedIndicator().equals(ind.id()), "Voice calls up " + ind.shortName());
                check(app.voice.statusText().startsWith("Showing"), "Voice says what it showed");
            }
            int rows = rows();
            app.go("body"); app.voice.handle("Blood oxygen.");
            check(app.currentPage().equals("status") && app.page.selectedIndicator().equals("spo2"), "Voice returns to Status from another page");
            app.voice.handle("record temperature 40 degrees"); check(app.page.selectedIndicator().equals("temp") && rows() == rows, "A spoken reading is not saved; only the panel is shown");
            app.voice.handle("delete everything"); check(app.page.selectedIndicator().equals("temp") && rows() == rows && app.voice.statusText().startsWith("No panel matched"), "Other commands do nothing");
            app.voice.useKey("smoke-key"); ((Button) app.voice.lookup("#voice-talk")).fire();
        }).thenCompose(v -> until(() -> app.voice.statusText().startsWith("Listening"), "voice starts listening"))
          .thenRun(() -> ((Button) app.voice.lookup("#voice-talk")).fire())
          .thenCompose(v -> until(() -> app.page.selectedIndicator().equals("sleep"), "a recording ends in the panel being shown, with no confirmation"))
          .thenRun(() -> { app.go("body"); app.bodyPage.select("brain"); })
          .thenCompose(v -> delay(1500)).thenRun(() -> {
            System.out.println("3D figure drawn: " + app.bodyPage.view().available());
            check(app.bodyPage.lookupAll(".list-row").size() == app.catalog.systems().size(), "Every body system is listed");
            var levels = app.page.session().systemLevels(app.page.missionDay());
            check(levels.get("brain") >= 1 && levels.get("lungs") == 0, "Body levels come from the same assessment as Status");
            check(app.bodyPage.lookup("#open-sleep") != null, "The chosen system lists its metrics");
            snap(app.stage.getScene().getRoot(), "2-body.png");
            ((Button) app.bodyPage.lookup("#open-mood")).fire();
            check(app.currentPage().equals("status") && app.page.selectedIndicator().equals("mood"), "Open on the body page brings the metric up on Status");
            app.page.setSelectedIndicator("hydration");
            check("fluids".equals(app.bodyPage.selectedSystem()), "Choosing a metric on Status picks its system on the body page");
            app.go("log");
            ((TextField) app.logPage.lookup("#reading-value-hr")).setText("61");
            ((TextField) app.logPage.lookup("#reading-value-strength")).setText("33");
            ((ToggleButton) app.logPage.lookup("#reading-choice-hydration-5")).fire();
            ((ToggleButton) app.logPage.lookup("#reading-choice-mood-4")).fire();
            app.logPage.applyCss(); app.logPage.layout(); snap(app.stage.getScene().getRoot(), "3-log.png");
            before = rows();
            ((Button) app.logPage.lookup("#log-save")).fire();
        }).thenCompose(v -> until(() -> rows() == before + 1 && ((Label) app.logPage.lookup("#log-feedback")).getText().contains("saved"), "the log entry reaches the database"))
          .thenRun(() -> {
            try {
                var last = new MeasurementDAO().findByAstronaut(app.crew.getValue().getId()).stream().max(java.util.Comparator.comparingInt(Measurement::getId)).orElseThrow();
                check(last.getHeartRate() == 61 && last.getUrineColor() == 5 && last.getStrength() == 33 && last.getMood() == 4 && last.getBodyTemp() == null, "The row holds exactly what was entered");
            } catch (Exception e) { throw new CompletionException(e); }
            var r = app.page.session().assess(app.page.session().today()).get("hydration");
            check(r.level() == 2 && "red".equals(r.direction()), "Pink to red urine is assessed as Act");
            check(app.page.session().systemLevels(app.page.session().today()).get("fluids") == 2, "The body page's kidney system follows the new reading");
            ((TextField) app.logPage.lookup("#reading-value-temp")).setText("99"); ((Button) app.logPage.lookup("#log-save")).fire();
        }).thenCompose(v -> until(() -> ((Label) app.logPage.lookup("#log-feedback")).getText().contains("Temperature"), "an impossible value is refused with a message"))
          .thenRun(() -> {
            check(rows() == before + 1, "...and nothing was saved");
            app.go("status"); app.page.setSelectedIndicator("hydration"); app.page.applyCss(); app.page.layout();
        }).thenCompose(v -> delay(1600)).thenRun(() -> {
            check(((Label) app.page.lookup("#save-feedback")).getText().isEmpty(), "A message from the log form does not linger on the Status page");
            snap(app.stage.getScene().getRoot(), "4-urine-colour.png");
            app.go("guides");
            check(app.guidesPage.lookupAll(".panel").size() == app.catalog.equipment().size(), "One guide card per piece of equipment");
            app.guidesPage.applyCss(); app.guidesPage.layout(); snap(app.stage.getScene().getRoot(), "5-guides.png");
            ((Button) app.guidesPage.lookup("#guide-urinechart")).fire();
        }).thenCompose(v -> delay(400)).thenRun(() -> {
            Parent guide = other("#guide-next"); check(guide != null, "A guide opens from the How to use page"); snap(guide, "6-guide.png");
            guide.getScene().getWindow().hide();
            check(Locale.getDefault().getLanguage().equals("en"), "The calendar starts in English whatever the computer's language");
            app.launch.show();
        }).thenCompose(v -> delay(500)).thenRun(() -> {
            snap(popup(), "7-calendar-english.png"); app.launch.hide();
            app.language.setValue("Português (Brasil)");
            check(Locale.getDefault().toLanguageTag().equals("pt-BR") && Database.setting("language", "").startsWith("Portugu"), "Choosing Portuguese switches the calendar and is remembered");
            check(app.launch.getConverter().toString(LocalDate.of(2026, 11, 25)).startsWith("25/11"), "Dates are written the Brazilian way");
            app.launch.show();
        }).thenCompose(v -> delay(500)).thenRun(() -> {
            snap(popup(), "8-calendar-portuguese.png"); app.launch.hide();
            app.language.setValue("English"); check(app.launch.getConverter().toString(LocalDate.of(2026, 11, 25)).startsWith("11/25"), "Back to English");
            Platform.runLater(app::addCrew);                     // a sheet waits for its answer, so it is opened outside this step
        }).thenCompose(v -> delay(700)).thenRun(() -> {
            Parent sheet = other("#crew-name"); snap(sheet, "9-add-crew.png"); ((TextField) sheet.lookup("#crew-name")).setText("Sam Okoro"); ((Button) sheet.lookup("#crew-save")).fire();
        }).thenCompose(v -> delay(500)).thenRun(() -> {
            check(app.crew.getItems().size() == 2 && app.crew.getValue().getName().equals("Sam Okoro"), "A crew member can be added and is selected");
            check(app.page.session().readings().isEmpty() && app.page.session().today() == 0, "A new crew member starts empty, on launch day");
            app.go("body");
        }).thenCompose(v -> delay(600)).thenRun(() -> {
            snap(app.stage.getScene().getRoot(), "10-new-crew-body.png");
            app.crew.setValue(app.crew.getItems().get(0)); app.go("status"); app.stage.setWidth(1240);
        }).thenCompose(v -> delay(500)).thenRun(() -> {
            snap(app.stage.getScene().getRoot(), "11-narrow.png");
            System.out.println("PASS: status, 12 voice panel commands, body page, log entry to database, urine colour groups, guides, calendar language, add crew");
        }).orTimeout(90, TimeUnit.SECONDS).whenComplete((v, f) -> Platform.runLater(() -> {
            if (f != null) { f.printStackTrace(); System.exit(1); }
            Platform.exit();
        }));
    }

    private int before;
    private int rows() {
        try (var con = Database.getConnection(); var rs = con.createStatement().executeQuery("SELECT count(*) FROM data")) { return rs.next() ? rs.getInt(1) : -1; }
        catch (Exception e) { throw new CompletionException(e); }
    }
    private Parent other(String selector) {
        return Window.getWindows().stream().filter(w -> w.isShowing() && w != app.stage && w.getScene() != null).map(w -> w.getScene().getRoot()).filter(p -> p.lookup(selector) != null).findFirst().orElse(null);
    }
    private Parent popup() {
        return Window.getWindows().stream().filter(w -> w.isShowing() && w != app.stage && w.getScene() != null).map(w -> w.getScene().getRoot()).filter(p -> p.lookup(".date-picker-popup") != null || p.getStyleClass().contains("date-picker-popup")).findFirst().orElseThrow(() -> new AssertionError("The calendar did not open"));
    }
    private static CompletableFuture<Void> delay(int ms) { var f = new CompletableFuture<Void>(); var p = new PauseTransition(Duration.millis(ms)); p.setOnFinished(e -> f.complete(null)); p.play(); return f; }
    private CompletableFuture<Void> until(BooleanSupplier ready, String what) { return poll(ready, what, System.nanoTime() + TimeUnit.SECONDS.toNanos(10)); }
    private CompletableFuture<Void> poll(BooleanSupplier ready, String what, long deadline) {
        if (ready.getAsBoolean()) { System.out.println("ok  " + what); return CompletableFuture.completedFuture(null); }
        if (System.nanoTime() > deadline) return CompletableFuture.failedFuture(new AssertionError("Timed out: " + what));
        return delay(80).thenCompose(v -> poll(ready, what, deadline));
    }
    private static void snap(Node node, String name) {
        try {
            var image = node.snapshot(null, null);
            var png = new java.awt.image.BufferedImage((int) image.getWidth(), (int) image.getHeight(), java.awt.image.BufferedImage.TYPE_INT_ARGB);
            for (int y = 0; y < png.getHeight(); y++) for (int x = 0; x < png.getWidth(); x++) png.setRGB(x, y, image.getPixelReader().getArgb(x, y));
            Files.createDirectories(Path.of("target", "smoke")); javax.imageio.ImageIO.write(png, "png", Path.of("target", "smoke", name).toFile());
        } catch (Exception e) { throw new CompletionException(e); }
    }
    private static void check(boolean ok, String what) { if (!ok) throw new AssertionError(what); System.out.println("ok  " + what); }
}
