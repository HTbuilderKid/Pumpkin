package com.example.healthmonitor.pages;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import org.hm.health.HealthCatalog;
import org.hm.health.HealthStatusPane;
import org.hm.health.ReadingInput;

import java.util.LinkedHashMap;
import java.util.Map;

public final class LogVitalsPage extends ScrollPane {
    public interface Saver { void save(Map<String, Double> values, Runnable whenSaved, java.util.function.Consumer<String> whenFailed); }

    private final Map<String, ReadingInput> inputs = new LinkedHashMap<>();
    private final Label who = new Label(), feedback = new Label();
    private final Button save = new Button("Save entry");
    private Saver saver;
    private HealthStatusPane guides;

    public LogVitalsPage(HealthCatalog catalog) {
        getStyleClass().add("health-page"); getStylesheets().add(HealthStatusPane.class.getResource("/health/health.css").toExternalForm());
        setFitToWidth(true); setHbarPolicy(ScrollBarPolicy.NEVER);
        Label title = new Label("Log vitals"); title.getStyleClass().add("page-title");
        who.getStyleClass().add("muted");
        Label lead = new Label("Fill in what you measured just now and leave the rest empty. Everything on this form is saved together as one entry.");
        lead.getStyleClass().add("body-text"); lead.setWrapText(true);
        FlowPane fields = new FlowPane(14, 14); fields.setPrefWrapLength(2400);
        for (var ind : catalog.daily()) {
            ReadingInput input = new ReadingInput(ind); inputs.put(ind.id(), input);
            Label name = new Label(ind.shortName()); name.getStyleClass().add("row-title");
            Label unit = new Label(ind.unit().replace("/ ", "1 to ")); unit.getStyleClass().add("muted");
            HBox head = new HBox(8, name, unit); head.setAlignment(Pos.BASELINE_LEFT);
            var equipment = catalog.equipmentFor(ind.id());
            if (equipment != null) {
                Region gap = new Region(); HBox.setHgrow(gap, javafx.scene.layout.Priority.ALWAYS);
                Button how = new Button("How?"); how.getStyleClass().add("mini"); how.setOnAction(e -> { if (guides != null) guides.openGuide(equipment.id()); });
                head.getChildren().addAll(gap, how);
            }
            VBox field = new VBox(9, head, input); field.getStyleClass().add("entry-card"); field.setId("log-" + ind.id());
            field.setPrefWidth(ind.input().choice() ? 646 : ind.input().picked() ? 316 : 316);
            fields.getChildren().add(field);
        }
        save.setId("log-save"); save.getStyleClass().add("primary"); save.setOnAction(e -> submit());
        Button clear = new Button("Clear"); clear.setOnAction(e -> { inputs.values().forEach(ReadingInput::clear); message("", false); });
        feedback.setId("log-feedback"); feedback.setWrapText(true);
        HBox actions = new HBox(10, save, clear, feedback); actions.setAlignment(Pos.CENTER_LEFT);
        VBox card = new VBox(18, lead, fields, actions); card.getStyleClass().add("panel");
        VBox head = new VBox(2, title, who); head.setPadding(new Insets(0, 5, 0, 5));
        VBox root = new VBox(18, head, card); root.setPadding(new Insets(22, 24, 28, 24));
        setContent(root);
    }

    public void bind(String heading, Saver saver, HealthStatusPane guides) {
        who.setText(heading); this.saver = saver; this.guides = guides; save.setDisable(saver == null);
        inputs.values().forEach(ReadingInput::clear); message("", false);
    }

    private void submit() {
        Map<String, Double> values = new LinkedHashMap<>();
        try {
            for (var e : inputs.entrySet()) { Double v = e.getValue().value(); if (v != null) values.put(e.getKey(), v); }
        } catch (IllegalArgumentException bad) { message(bad.getMessage(), true); return; }
        if (values.isEmpty()) { message("Enter at least one reading first.", true); return; }
        save.setDisable(true); message("Saving…", false);
        saver.save(values, () -> { save.setDisable(false); inputs.values().forEach(ReadingInput::clear); message(values.size() + (values.size() == 1 ? " reading saved." : " readings saved as one entry."), false); },
                problem -> { save.setDisable(false); message(problem, true); });
    }
    private void message(String text, boolean bad) { feedback.setText(text); feedback.setStyle("-fx-text-fill:" + (bad ? HealthStatusPane.levelTextColor(3) : "#6e6e72") + ";"); }
}
