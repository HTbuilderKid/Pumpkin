package org.hm.health;
import javafx.scene.layout.FlowPane;
import javafx.scene.control.*;
import java.util.*;

public final class ReadingInput extends FlowPane {
    private final ToggleGroup scale=new ToggleGroup();
    private TextField number;
    public ReadingInput(HealthCatalog.Indicator indicator){
        setHgap(6);setVgap(6);setPrefWrapLength(indicator.input().choice()?560:indicator.input().type().equals("scale")?(indicator.input().max()-indicator.input().min()+1)*46-6:120);
        var input=indicator.input();
        if(input.choice()){
            for(int value=(int)input.min();value<=input.max();value++){
                var option=input.options().get(value-(int)input.min());
                ToggleButton button=new ToggleButton(option.label());button.setId("reading-choice-"+indicator.id()+"-"+value);
                var swatch=new javafx.scene.shape.Circle(8,javafx.scene.paint.Color.web(option.color()));swatch.setStroke(javafx.scene.paint.Color.web("#141414",.18));button.setGraphic(swatch);button.setGraphicTextGap(8);
                button.getStyleClass().add("colour-choice");button.setToggleGroup(scale);button.setUserData((double)value);
                button.setAccessibleText(indicator.shortName()+": "+option.label()+", "+option.note());button.setTooltip(new Tooltip(option.note()));Plush.press(button,.94);getChildren().add(button);
            }
        }else if(input.type().equals("scale")){
            for(int value=(int)input.min();value<=input.max();value++){
                ToggleButton button=new ToggleButton(Integer.toString(value));button.setId("reading-choice-"+indicator.id()+"-"+value);
                button.getStyleClass().add("scale-choice");button.setToggleGroup(scale);button.setUserData((double)value);
                button.setAccessibleText(indicator.shortName()+": "+value+", "+input.labels().get(value-(int)input.min()));
                button.setTooltip(new Tooltip(input.labels().get(value-(int)input.min())));Plush.press(button,.9);getChildren().add(button);
            }
        }else{
            number=new TextField();number.setId("reading-value-"+indicator.id());number.setPrefWidth(120);number.setPromptText(input.placeholder());number.setAccessibleText(indicator.name()+" in "+indicator.unit());
            getChildren().add(number);
        }
    }
    public void clear(){if(number!=null)number.clear();else scale.selectToggle(null);}
    /** The entered value, null when left empty. Throws IllegalArgumentException when what was typed is not a number. */
    public Double value(){
        if(number==null)return scale.getSelectedToggle()==null?null:(Double)scale.getSelectedToggle().getUserData();
        String text=number.getText().trim();if(text.isEmpty())return null;
        try{double v=Double.parseDouble(text);if(!Double.isFinite(v))throw new NumberFormatException();return v;}
        catch(NumberFormatException e){throw new IllegalArgumentException("Enter a valid finite number.");}
    }
}
