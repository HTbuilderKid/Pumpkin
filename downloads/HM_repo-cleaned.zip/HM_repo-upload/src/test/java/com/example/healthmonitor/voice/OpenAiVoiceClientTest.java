package com.example.healthmonitor.voice;

import com.sun.net.httpserver.HttpServer;
import org.hm.health.HealthCatalog;
import org.junit.jupiter.api.Test;

import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OpenAiVoiceClientTest {
    @Test void aRecordingIsSentAsWavAndTheTextComesBack() throws Exception {
        var server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0); List<String> paths = new ArrayList<>();
        server.createContext("/v1/", e -> { try (e) {
            paths.add(e.getRequestURI().getPath()); String body = new String(e.getRequestBody().readAllBytes(), StandardCharsets.ISO_8859_1);
            if (!"Bearer test-key".equals(e.getRequestHeaders().getFirst("Authorization"))) throw new AssertionError("Auth header");
            if (!body.contains("gpt-4o-mini-transcribe") || !body.contains("command.wav") || !body.contains("RIFF") || !body.contains("name=\"prompt\"") || !body.contains("grip strength")) throw new AssertionError("WAV multipart");
            byte[] bytes = "{\"text\":\"show urine colour\"}".getBytes(StandardCharsets.UTF_8); e.sendResponseHeaders(200, bytes.length); e.getResponseBody().write(bytes);
        } });
        server.start();
        try {
            var client = new OpenAiVoiceClient(HttpClient.newHttpClient(), URI.create("http://127.0.0.1:" + server.getAddress().getPort() + "/v1/"));
            byte[] wav = MicrophoneCapture.wav(new byte[16000], new javax.sound.sampled.AudioFormat(16000, 16, 1, true, false));
            assertEquals("show urine colour", client.transcribe(wav, "test-key"));
            assertEquals(List.of("/v1/audio/transcriptions"), paths);
        } finally { server.stop(0); }
    }

    @Test void errorsDoNotExposeCredentials() throws Exception {
        var server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/", e -> { try (e) { byte[] b = "secret-key-value".getBytes(); e.sendResponseHeaders(401, b.length); e.getResponseBody().write(b); } });
        server.start();
        try {
            var c = new OpenAiVoiceClient(HttpClient.newHttpClient(), URI.create("http://127.0.0.1:" + server.getAddress().getPort() + "/"));
            var error = assertThrows(java.io.IOException.class, () -> c.transcribe(new byte[64], "secret-key-value"));
            assertFalse(error.getMessage().contains("secret-key-value"));
        } finally { server.stop(0); }
    }

    @Test void everyStatusPanelHasAVoiceCommand() throws Exception {
        var catalog = HealthCatalog.load();
        for (var ind : catalog.daily()) {
            assertTrue(VoiceCommand.PHRASES.containsKey(ind.id()), "no phrase for " + ind.id());
            for (String phrase : VoiceCommand.PHRASES.get(ind.id())) {
                var c = VoiceCommand.match("Show " + phrase + ", please.");
                assertEquals(VoiceCommand.Action.SHOW_METRIC, c.action(), phrase); assertEquals(ind.id(), c.indicator(), phrase);
            }
            assertEquals(ind.id(), VoiceCommand.match(ind.shortName()).indicator(), ind.shortName());
        }
        assertEquals(catalog.daily().size(), VoiceCommand.PHRASES.size());
    }

    @Test void voiceCanOnlySelectPanels() {
        assertEquals("bp_dia", VoiceCommand.match("lower blood pressure").indicator());
        assertEquals("bp_sys", VoiceCommand.match("Blood pressure").indicator());
        assertEquals("spo2", VoiceCommand.match("show me my blood oxygen").indicator());
        assertEquals("hydration", VoiceCommand.match("Urine color.").indicator());
        for (String other : List.of("record temperature 36.8", "delete everything", "select Alex Rivera", "mission day 38", "", "blood"))
            if (!other.contains("temperature")) assertEquals(VoiceCommand.Action.UNSUPPORTED, VoiceCommand.match(other).action(), other);
        var c = VoiceCommand.match("record temperature 36.8"); assertEquals(VoiceCommand.Action.SHOW_METRIC, c.action()); assertEquals("temp", c.indicator());
        assertEquals(VoiceCommand.Action.HELP, VoiceCommand.match("help").action());
        assertEquals(VoiceCommand.Action.UNSUPPORTED, VoiceCommand.match("sleep and mood").action());
    }
}
